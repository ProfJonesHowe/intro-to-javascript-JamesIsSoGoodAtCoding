function greetUser() 
{
  let name = document.getElementById("nameInput").value;'
  let lastName = "Markson";
  let message = "Hello, " + name + " " + lastName + "! Welcome to JavaScript.";
  document.getElementById("greeting").innerHTML = message;
}